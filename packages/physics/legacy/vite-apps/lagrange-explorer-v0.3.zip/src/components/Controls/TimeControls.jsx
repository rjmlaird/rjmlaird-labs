export default function TimeControls(){return null}
