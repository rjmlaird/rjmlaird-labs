export function gamma(beta){ return 1/Math.sqrt(1-beta*beta); }
export function timeDilation(properTime,beta){ return properTime*gamma(beta); }
export function lengthContraction(restLength,beta){ return restLength/gamma(beta); }
export function relativisticMass(restMass,beta){ return restMass*gamma(beta); }
export function energy(restMass,beta){ return restMass*gamma(beta); }
export function speedFractionLabel(beta){ return `${(beta*100).toFixed(beta<.1?1:0)}% c`; }
