# Design notes

The interface deliberately prioritises animation and comparison over equations. Cyan represents the physical system/light; amber is used for reference paths and energy. Text is kept short and the main γ value is always visible.

Accessibility: controls are keyboard-focusable native buttons and range input; information is not conveyed by colour alone; responsive layout supports narrow screens.
