# Physics notes

For β = v/c, the Lorentz factor is γ = 1 / √(1 − β²).

Time dilation: Δt = γ Δτ.

Length contraction: L = L₀ / γ, for a length measured parallel to the direction of motion.

The UI includes a relativistic-mass readout as an historical convention, m_rel = γm. Modern relativity normally treats invariant/rest mass as unchanged and instead describes total energy E = γmc² and momentum p = γmv.

The visualisations are illustrative rather than precision simulations. The train and light-clock scenes are designed to communicate frame-dependent measurements and the role of c as an invariant speed.
