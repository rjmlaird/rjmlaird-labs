/**
 * Approximate initial conditions for bounded motion near a collinear L-point.
 *
 * These are deliberately labelled SEEDS, not mission ephemerides.  They use
 * the linearised CR3BP about the selected equilibrium and are intended for
 * an educational sandbox.  True halo/Lissajous families require nonlinear
 * continuation / Richardson or differential-correction methods.
 */

function planarCentreFrequency(point, mu) {
  const x = point.x;
  const r1 = Math.abs(x + mu);
  const r2 = Math.abs(x - 1 + mu);
  const k = (1 - mu) / (r1 ** 3) + mu / (r2 ** 3);
  const omegaXX = 1 + 2 * k;
  const omegaYY = 1 - k;

  // Characteristic equation for the planar linearised system:
  // λ⁴ + (2 - Ωxx - Ωyy)λ² + ΩxxΩyy = 0.
  const a = 2 - omegaXX - omegaYY;
  const b = omegaXX * omegaYY;
  const discriminant = Math.max(0, a * a - 4 * b);
  const root1 = (-a + Math.sqrt(discriminant)) / 2;
  const root2 = (-a - Math.sqrt(discriminant)) / 2;
  const negativeRoot = root1 < 0 ? root1 : root2;

  return {
    omega: Math.sqrt(Math.max(1e-9, -negativeRoot)),
    omegaXX
  };
}

export function lissajousSeed(point, mu, amplitude = 0.002) {
  const { omega, omegaXX } = planarCentreFrequency(point, mu);
  const Ax = amplitude;
  const Ay = -((omega * omega) + omegaXX) / (2 * omega) * Ax;

  return [
    point.x + Ax,
    point.y,
    point.z,
    0,
    Ay * omega,
    0
  ];
}

export function haloSeed(point, mu, amplitude = 0.002, zAmplitude = amplitude * 0.8) {
  const planar = lissajousSeed(point, mu, amplitude);
  return [
    planar[0],
    planar[1],
    point.z + zAmplitude,
    planar[3],
    planar[4],
    0
  ];
}

export const ORBIT_TYPES = [
  { id: 'point', label: 'L-point equilibrium' },
  { id: 'lissajous', label: 'Lissajous seed' },
  { id: 'halo', label: 'Halo seed' }
];
