export const scenarios=[
 {id:'slow',label:'Everyday',beta:0.1,note:'At 10% of c, the effects are real but subtle.'},
 {id:'half',label:'0.5 c',beta:0.5,note:'A good speed for seeing the effects clearly.'},
 {id:'fast',label:'0.9 c',beta:0.9,note:'Time, distance and energy now diverge dramatically.'},
 {id:'extreme',label:'0.99 c',beta:0.99,note:'A tiny increase in speed produces a large change in γ.'}
];
