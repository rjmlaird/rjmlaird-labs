# Leicester & Leicestershire Rainfall Map

EA Rainfall API (~1000 telemetry gauges, 15-minute totals, last 4 weeks) behind one cached function.

    npm i -g vercel
    vercel dev      # local
    vercel --prod

- `api/rain.js` lists gauges in the area, pulls 7 days of readings per gauge in parallel and returns hourly totals
  (edge cache 10 min, stale-while-revalidate 30 min). The browser makes one request.
- Browser cache (localStorage, 10 min) sits in front, with a stale fallback if the network fails.
- Gauges have no names and their location is rounded to a 100 m grid (EA information-protection rule), so they are labelled by grid reference.
- Gauges upload once or twice a day, so the newest hours are often missing. Gaps are shown as "no data", never as 0.

Attribution: this uses Environment Agency rainfall data from the real-time data API (Beta), OGL v3.0.
