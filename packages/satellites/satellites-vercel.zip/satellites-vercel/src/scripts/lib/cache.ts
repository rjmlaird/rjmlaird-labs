// Browser-side cache for API responses: memory -> IndexedDB -> network.
//
//   fresh  (< TTL)        return the cached copy, no network
//   stale  (< SWR window) return the cached copy instantly, refresh in background
//   older / missing       go to the network; if that fails, fall back to any copy we have
//
// Celestrak only republishes element sets about every 2 hours, so a 2h TTL
// loses nothing, and the stale-while-revalidate window means repeat visits
// paint immediately instead of waiting on a download.

type Entry = { text: string; at: number };

const DB_NAME = 'satellites-cache';
const STORE = 'responses';

export const TTL_MS = 2 * 60 * 60 * 1000;
export const SWR_MS = 24 * 60 * 60 * 1000;

const mem = new Map<string, Entry>();
const inflight = new Map<string, Promise<string>>();

let dbPromise: Promise<IDBDatabase | null> | null = null;

function openDb(): Promise<IDBDatabase | null> {
  if (dbPromise) return dbPromise;
  dbPromise = new Promise((resolve) => {
    try {
      const req = indexedDB.open(DB_NAME, 1);
      req.onupgradeneeded = () => req.result.createObjectStore(STORE);
      req.onsuccess = () => resolve(req.result);
      req.onerror = () => resolve(null);
      req.onblocked = () => resolve(null);
    } catch {
      resolve(null); // private mode / storage disabled: run uncached
    }
  });
  return dbPromise;
}

async function idbGet(key: string): Promise<Entry | null> {
  const db = await openDb();
  if (!db) return null;
  return new Promise((resolve) => {
    try {
      const req = db.transaction(STORE, 'readonly').objectStore(STORE).get(key);
      req.onsuccess = () => resolve((req.result as Entry | undefined) ?? null);
      req.onerror = () => resolve(null);
    } catch {
      resolve(null);
    }
  });
}

async function idbPut(key: string, entry: Entry): Promise<void> {
  const db = await openDb();
  if (!db) return;
  try {
    db.transaction(STORE, 'readwrite').objectStore(STORE).put(entry, key);
  } catch {
    /* quota or disabled storage: ignore, we just lose the cache */
  }
}

function refresh(url: string): Promise<string> {
  const existing = inflight.get(url);
  if (existing) return existing;

  const p = (async () => {
    const r = await fetch(url);
    if (!r.ok) {
      let detail = '';
      try {
        detail = ((await r.json()) as { error?: string }).error || '';
      } catch {
        /* not JSON */
      }
      throw new Error(detail || 'HTTP ' + r.status);
    }
    const text = await r.text();
    const entry = { text, at: Date.now() };
    mem.set(url, entry);
    void idbPut(url, entry);
    return text;
  })().finally(() => inflight.delete(url));

  inflight.set(url, p);
  return p;
}

export async function cachedFetchText(
  url: string,
  opts: { ttlMs?: number; swrMs?: number } = {},
): Promise<string> {
  const ttl = opts.ttlMs ?? TTL_MS;
  const swr = opts.swrMs ?? SWR_MS;

  const entry = mem.get(url) ?? (await idbGet(url));
  const age = entry ? Date.now() - entry.at : Infinity;

  if (entry && age < ttl) {
    mem.set(url, entry);
    return entry.text;
  }
  if (entry && age < swr) {
    mem.set(url, entry);
    refresh(url).catch(() => {}); // background update for next time
    return entry.text;
  }
  try {
    return await refresh(url);
  } catch (e) {
    if (entry) return entry.text; // offline / API down: stale beats nothing
    throw e;
  }
}
