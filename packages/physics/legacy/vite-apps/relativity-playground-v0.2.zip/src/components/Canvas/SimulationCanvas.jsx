// Scene rendering is currently co-located in main.jsx; this placeholder keeps the planned component structure.
export default function SimulationCanvas(){return null}
