// Shared helpers for the Celestrak proxy endpoints (api/gp.js, api/satcat.js).
// Files under api/_lib are not exposed as routes by Vercel.

export const SATCAT_UPSTREAM = 'https://celestrak.org/pub/satcat.csv';

export const gpUpstream = (group) =>
  `https://celestrak.org/NORAD/elements/gp.php?GROUP=${encodeURIComponent(group)}&FORMAT=tle`;

// Allow-list rather than "any string": stops anyone using this endpoint to
// hammer Celestrak or blow up the CDN cache with arbitrary keys. These match
// the options offered in the UI. Extend via the EXTRA_GROUPS env var
// (comma-separated) without a code change.
const BASE_GROUPS = [
  'active',
  'stations',
  'visual',
  'gps-ops',
  'starlink',
  'oneweb',
  'weather',
  'science',
  'geo',
  'last-30-days',
];
const extra = (process.env.EXTRA_GROUPS || '')
  .split(',')
  .map((s) => s.trim().toLowerCase())
  .filter(Boolean);
export const GROUPS = new Set([...BASE_GROUPS, ...extra]);

// Celestrak refreshes GP data roughly every 2 hours and asks clients not to
// poll more often. So: edge-cache for 2h, serve stale for a day while
// revalidating in the background, and keep serving stale for a week if
// Celestrak is down.
export const CACHE_CONTROL =
  'public, max-age=300, s-maxage=7200, stale-while-revalidate=86400, stale-if-error=604800';

const UA = 'rjmlaird-labs-satellites/1.0 (+https://satellites.labs.rjmlaird.co.uk)';

export class UpstreamError extends Error {}

export async function fetchUpstream(url, timeoutMs = 25000) {
  const ac = new AbortController();
  const timer = setTimeout(() => ac.abort(), timeoutMs);
  try {
    const r = await fetch(url, { headers: { 'user-agent': UA }, signal: ac.signal });
    if (!r.ok) throw new UpstreamError(`Celestrak responded with HTTP ${r.status}`);
    return await r.text();
  } catch (e) {
    if (e instanceof UpstreamError) throw e;
    if (e && e.name === 'AbortError') throw new UpstreamError('Celestrak timed out');
    throw new UpstreamError('Could not reach Celestrak');
  } finally {
    clearTimeout(timer);
  }
}

export function errorResponse(status, message) {
  return new Response(JSON.stringify({ error: message }), {
    status,
    headers: { 'content-type': 'application/json', 'cache-control': 'no-store' },
  });
}

/** Returns a validated group name, or an error Response. */
export function readGroup(request) {
  const raw = new URL(request.url).searchParams.get('group');
  const group = (raw || '').trim().toLowerCase();
  if (!group) return errorResponse(400, 'Missing ?group= parameter');
  if (!GROUPS.has(group)) return errorResponse(400, `Unknown group "${group}"`);
  return group;
}

/** NORAD catalogue numbers from a 3-line TLE file. */
export function parseTleNoradIds(text) {
  const lines = text.split(/\r?\n/).filter((l) => l.trim().length > 0);
  const ids = [];
  for (let i = 0; i + 2 < lines.length; i += 3) {
    if (!lines[i + 1].startsWith('1 ') || !lines[i + 2].startsWith('2 ')) continue;
    const id = parseInt(lines[i + 1].substring(2, 7).trim(), 10);
    if (!isNaN(id)) ids.push(id);
  }
  return ids;
}

export function splitCSVLine(line) {
  const result = [];
  let cur = '';
  let inQ = false;
  for (let i = 0; i < line.length; i++) {
    const c = line[i];
    if (c === '"') {
      if (inQ && line[i + 1] === '"') {
        cur += '"';
        i++;
      } else inQ = !inQ;
    } else if (c === ',' && !inQ) {
      result.push(cur);
      cur = '';
    } else {
      cur += c;
    }
  }
  result.push(cur);
  return result;
}

export function csvCell(v) {
  return /[",\n\r]/.test(v) ? '"' + v.replace(/"/g, '""') + '"' : v;
}
