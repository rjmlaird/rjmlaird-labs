export default function SpeedSlider(){return null}
