export default function LagrangeLabels(){return null}
