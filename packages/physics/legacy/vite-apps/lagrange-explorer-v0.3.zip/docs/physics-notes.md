# CR3BP physics notes

The lab uses the circular restricted three-body problem in canonical rotating coordinates. The primaries have total mass 1, separation 1 and mean motion 1. The mass parameter is μ = m2/(m1+m2).

The spacecraft state is `[x,y,z,vx,vy,vz]`. With r1 and r2 measured from the two primaries:

`xddot - 2 ydot = ∂Ω/∂x`
`yddot + 2 xdot = ∂Ω/∂y`
`zddot = ∂Ω/∂z`

where `Ω = 1/2(x²+y²) + (1-μ)/r1 + μ/r2`.

The code integrates the first-order system with classical fourth-order Runge–Kutta. The Jacobi constant is tracked as a numerical diagnostic.

L1–L3 are found by bisection on the collinear equilibrium equation. L4/L5 are analytic. This is an educational model: it ignores eccentricity, third-body perturbations, solar radiation pressure, ephemerides and spacecraft-specific forces.
