import{lagrangePoints}from'./threeBody.js';export{lagrangePoints};
