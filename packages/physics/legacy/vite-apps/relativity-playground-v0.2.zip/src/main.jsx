import React,{useEffect,useRef,useState} from 'react';
import {createRoot} from 'react-dom/client';
import {gamma,lengthContraction,relativisticMass,speedFractionLabel} from './physics/relativity';
import './index.css';

const scenes=['Light clock','Moving train','Length contraction','Energy & mass','Spacetime diagram','Simultaneity'];
const presets=[['Everyday',.1],['Half light speed',.5],['Fast',.9],['Near c',.99]];

function Scene({scene,beta,playing}){
 const ref=useRef(null);
 useEffect(()=>{let raf; const start=performance.now(); const draw=now=>{const c=ref.current,ctx=c.getContext('2d'),d=devicePixelRatio||1,w=c.clientWidth,h=c.clientHeight;c.width=w*d;c.height=h*d;ctx.setTransform(d,0,0,d,0,0);ctx.clearRect(0,0,w,h);ctx.fillStyle='#080d16';ctx.fillRect(0,0,w,h); const t=playing?(now-start)/1000:0; const g=gamma(beta);
 ctx.strokeStyle='#273449';ctx.lineWidth=1;for(let x=0;x<w;x+=48){ctx.beginPath();ctx.moveTo(x,0);ctx.lineTo(x,h);ctx.stroke()}for(let y=0;y<h;y+=48){ctx.beginPath();ctx.moveTo(0,y);ctx.lineTo(w,y);ctx.stroke()}
 if(scene==='Light clock'){drawClock(ctx,w,h,beta,t)} else if(scene==='Moving train'){drawTrain(ctx,w,h,beta,t)} else if(scene==='Length contraction'){drawRod(ctx,w,h,beta,t)} else if(scene==='Energy & mass') drawEnergy(ctx,w,h,beta,g,t); else if(scene==='Spacetime diagram') drawSpacetime(ctx,w,h,beta,g); else drawSimultaneity(ctx,w,h,beta,g); if(playing)raf=requestAnimationFrame(draw)}; draw(performance.now()); return()=>cancelAnimationFrame(raf)},[scene,beta,playing]);
 return <canvas ref={ref}/>;
}
function drawClock(ctx,w,h,b,t){const x=w*.5,y=h*.48;const height=100,dx=Math.min(75,b*95);ctx.strokeStyle='#7dd3fc';ctx.lineWidth=4;ctx.beginPath();ctx.moveTo(x-dx,y-height);ctx.lineTo(x+dx,y-height);ctx.moveTo(x-dx,y+height);ctx.lineTo(x+dx,y+height);ctx.stroke();ctx.fillStyle='#e5f6ff';ctx.fillRect(x-dx-7,y-height-6,dx*2+14,12);ctx.fillRect(x-dx-7,y+height-6,dx*2+14,12);const phase=((t*(1/Math.max(0.08,Math.sqrt(1-b*b))))%2);const p=phase<1?phase:2-phase;ctx.strokeStyle='#fbbf24';ctx.lineWidth=3;ctx.beginPath();ctx.moveTo(x-dx,y+height);ctx.lineTo(x+dx*(p),y+height*(1-2*p));ctx.stroke();ctx.fillStyle='#94a3b8';ctx.font='14px system-ui';ctx.textAlign='center';ctx.fillText('moving light clock',x,y+height+45);ctx.fillText('longer diagonal path in the lab frame',x,y+height+66)}
function drawTrain(ctx,w,h,b,t){const y=h*.58;const speed=80+b*240;const x=((t*speed)%(w+320))-180;ctx.strokeStyle='#64748b';ctx.lineWidth=4;ctx.beginPath();ctx.moveTo(0,y+55);ctx.lineTo(w,y+55);ctx.stroke();ctx.fillStyle='#38bdf8';ctx.fillRect(x,y-55,240,y?90:90);ctx.fillStyle='#0f172a';for(let i=0;i<3;i++)ctx.fillRect(x+25+i*68,y-30,50,35);ctx.fillStyle='#cbd5e1';ctx.beginPath();ctx.arc(x+55,y+43,15,0,Math.PI*2);ctx.arc(x+190,y+43,15,0,Math.PI*2);ctx.fill();ctx.fillStyle='#f8fafc';ctx.font='15px system-ui';ctx.fillText('TRAIN FRAME',Math.max(70,Math.min(w-70,x+120)),y-72);ctx.fillStyle='#94a3b8';ctx.fillText('platform frame',80,y+90)}
function drawRod(ctx,w,h,b,t){const g=gamma(b),rest=w*.48,obs=rest/g,x=w*.26,y=h*.48;ctx.fillStyle='#38bdf8';ctx.fillRect(x,y-18,obs,36);ctx.strokeStyle='#fbbf24';ctx.lineWidth=2;ctx.setLineDash([6,6]);ctx.strokeRect(x,y-18,rest,36);ctx.setLineDash([]);ctx.fillStyle='#f8fafc';ctx.font='14px system-ui';ctx.fillText('observed length L',x,y+55);ctx.fillStyle='#fbbf24';ctx.fillText('rest length L₀',x,y+78)}
function drawEnergy(ctx,w,h,b,g,t){const cx=w*.5,cy=h*.52,r=40+b*120;ctx.strokeStyle='#38bdf8';ctx.lineWidth=4;ctx.beginPath();ctx.arc(cx,cy,r,0,Math.PI*2);ctx.stroke();ctx.fillStyle='#fbbf24';ctx.beginPath();ctx.arc(cx,cy,12,0,Math.PI*2);ctx.fill();for(let i=0;i<8;i++){const a=t*.5+i*Math.PI/4;ctx.strokeStyle='#fbbf24';ctx.beginPath();ctx.moveTo(cx+Math.cos(a)*(r+12),cy+Math.sin(a)*(r+12));ctx.lineTo(cx+Math.cos(a)*(r+30),cy+Math.sin(a)*(r+30));ctx.stroke()}ctx.fillStyle='#e2e8f0';ctx.font='15px system-ui';ctx.textAlign='center';ctx.fillText('asymptotically harder to add speed near c',cx,cy+r+58);ctx.textAlign='left'}


function diagramFrame(ctx,w,h){
 const left=70,right=w-30,top=30,bottom=h-55;
 ctx.strokeStyle='#475569';ctx.lineWidth=1;
 ctx.beginPath();ctx.moveTo(left,top);ctx.lineTo(left,bottom);ctx.lineTo(right,bottom);ctx.stroke();
 ctx.fillStyle='#94a3b8';ctx.font='12px system-ui';ctx.fillText('ct',left-24,top+5);ctx.fillText('x',right+8,bottom+4);
 return {left,right,top,bottom,cx:(left+right)/2,cy:bottom};
}
function drawSpacetime(ctx,w,h,b,g){
 const d=diagramFrame(ctx,w,h), scale=Math.min((d.right-d.left)*.33,(d.bottom-d.top)*.38);
 // Light cone
 ctx.strokeStyle='#fbbf2466';ctx.setLineDash([5,5]);ctx.beginPath();ctx.moveTo(d.cx,d.cy);ctx.lineTo(d.cx-scale,d.cy-scale);ctx.moveTo(d.cx,d.cy);ctx.lineTo(d.cx+scale,d.cy-scale);ctx.stroke();ctx.setLineDash([]);
 // Rest-frame axes
 ctx.strokeStyle='#38bdf8';ctx.lineWidth=2;ctx.beginPath();ctx.moveTo(d.cx,d.cy);ctx.lineTo(d.cx,d.cy-scale*1.25);ctx.moveTo(d.cx,d.cy);ctx.lineTo(d.cx+scale*1.25,d.cy);ctx.stroke();
 // Moving frame axes x' and ct'
 const k=b;
 ctx.strokeStyle='#f472b6';ctx.lineWidth=2;ctx.beginPath();ctx.moveTo(d.cx,d.cy);ctx.lineTo(d.cx+scale*1.15,d.cy-k*scale*1.15);ctx.moveTo(d.cx,d.cy);ctx.lineTo(d.cx-k*scale*1.15,d.cy-scale*1.15);ctx.stroke();
 ctx.fillStyle='#e2e8f0';ctx.font='12px system-ui';ctx.fillText('ct',d.cx+7,d.top+3);ctx.fillText('x',d.right-4,d.cy-7);ctx.fillStyle='#f9a8d4';ctx.fillText("ct′",d.cx-k*scale*1.15+7,d.cy-scale*1.15);ctx.fillText("x′",d.right-18,d.cy-k*scale*1.15-7);
 // event and worldline
 ctx.fillStyle='#fbbf24';ctx.beginPath();ctx.arc(d.cx+scale*.48,d.cy-scale*.48,5,0,Math.PI*2);ctx.fill();
 ctx.fillStyle='#cbd5e1';ctx.fillText('same event',d.cx+scale*.48+10,d.cy-scale*.48+4);
 ctx.fillStyle='#64748b';ctx.fillText('Blue: platform frame',d.left,d.bottom+30);ctx.fillStyle='#f9a8d4';ctx.fillText('Pink: moving frame',d.left+155,d.bottom+30);
}
function drawSimultaneity(ctx,w,h,b,g){
 const d=diagramFrame(ctx,w,h);
 // Two events simultaneous in platform frame
 const y=d.cy-d.bottom*.22;
 ctx.strokeStyle='#38bdf8';ctx.lineWidth=2;ctx.beginPath();ctx.moveTo(d.left,y);ctx.lineTo(d.right,y);ctx.stroke();
 ctx.fillStyle='#38bdf8';ctx.beginPath();ctx.arc(d.cx-100,y,6,0,Math.PI*2);ctx.arc(d.cx+100,y,6,0,Math.PI*2);ctx.fill();
 // Tilted simultaneity line in moving frame
 const slope=-b*.55;const y0=d.cy-d.bottom*.22;
 ctx.strokeStyle='#f472b6';ctx.lineWidth=3;ctx.beginPath();ctx.moveTo(d.left,y0+slope*(d.left-d.cx));ctx.lineTo(d.right,y0+slope*(d.right-d.cx));ctx.stroke();
 ctx.fillStyle='#e2e8f0';ctx.font='12px system-ui';ctx.fillText('A',d.cx-112,y-12);ctx.fillText('B',d.cx+108,y-12);ctx.fillText('A and B are simultaneous here',d.left,d.top+16);ctx.fillStyle='#f9a8d4';ctx.fillText("But not simultaneous in the moving frame",d.left,d.top+35);
 ctx.fillStyle='#94a3b8';ctx.fillText('Changing frames changes which distant events share the same time coordinate.',d.left,d.bottom+30);
}

function App(){const [beta,setBeta]=useState(.5),[scene,setScene]=useState(0),[playing,setPlaying]=useState(true);const g=gamma(beta),contract=lengthContraction(10,beta),mass=relativisticMass(1,beta);return <div className="app"><header><div><div className="eyebrow">SPECIAL RELATIVITY • INTERACTIVE LAB</div><h1>Relativity Playground</h1><p>Move through spacetime. Watch clocks slow, lengths contract and γ climb.</p></div><button className="pause" onClick={()=>setPlaying(!playing)}>{playing?'Pause':'Play'} animation</button></header><main><section className="hero"><div className="scene-wrap"><Scene scene={scenes[scene]} beta={beta} playing={playing}/><div className="scene-label">{scenes[scene]}</div></div><aside className="controls"><label className="speed-label">VELOCITY <strong>{speedFractionLabel(beta)}</strong></label><input type="range" min="0" max=".999" step=".001" value={beta} onChange={e=>setBeta(+e.target.value)}/><div className="preset-grid">{presets.map(([n,v])=><button key={n} onClick={()=>setBeta(v)} className={Math.abs(beta-v)<.001?'active':''}>{n}<span>{Math.round(v*100)}% c</span></button>)}</div><div className="gamma"><span>γ</span><strong>{g.toFixed(g<10?3:2)}</strong><small>Lorentz factor</small></div><div className="readouts"><div><span>1 s moving</span><b>{g.toFixed(3)} s lab</b></div><div><span>10 m at rest</span><b>{contract.toFixed(2)} m observed</b></div><div><span>1 kg rest mass</span><b>{mass.toFixed(3)} kg*</b></div></div><p className="note">* “Relativistic mass” is an older convention. Modern treatments usually keep invariant mass fixed and describe the increase in total energy and momentum instead.</p></aside></section><nav className="tabs">{scenes.map((s,i)=><button key={s} className={scene===i?'selected':''} onClick={()=>setScene(i)}>{s}</button>)}</nav><section className="explain"><div><span className="num">01</span><h2>One speed, several consequences</h2><p>The slider controls <em>v/c</em>. The closer you get to the speed of light, the more strongly the Lorentz factor changes what different observers measure.</p></div><div><span className="num">02</span><h2>Nothing locally feels “slow”</h2><p>The moving observer’s own clock ticks normally. Time dilation appears when comparing clocks in different inertial frames.</p></div><div><span className="num">03</span><h2>Light sets the limit</h2><p>The sandbox uses special relativity in flat spacetime. It does not model gravity, acceleration, or general relativity.</p></div></section></main><footer>Relativity Playground · visual intuition first · <span>c = 299,792,458 m/s</span></footer></div>}
createRoot(document.getElementById('root')).render(<App/>);
