export function lorentz({t,x},beta){const g=1/Math.sqrt(1-beta*beta); return {tPrime:g*(t-beta*x),xPrime:g*(x-beta*t)};}
