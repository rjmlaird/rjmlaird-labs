export const G=6.67430e-11;export const CANONICAL={distance:1,mass:1,meanMotion:1};
