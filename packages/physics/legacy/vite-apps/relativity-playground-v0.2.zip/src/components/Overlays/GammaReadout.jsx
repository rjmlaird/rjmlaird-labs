export default function GammaReadout(){return null}
