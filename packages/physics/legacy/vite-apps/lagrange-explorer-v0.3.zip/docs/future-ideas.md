# Future ideas

- Real ephemeris mode and dimensional units
- Halo/Lissajous orbit initial-condition presets
- Station-keeping Δv model
- Poincaré sections and zero-velocity curves
- Stable/unstable manifold visualisation
- 3D camera and z perturbations
- Mission trajectory overlays
