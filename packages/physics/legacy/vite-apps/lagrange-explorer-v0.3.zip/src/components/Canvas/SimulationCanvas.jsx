export default function SimulationCanvas(){ return null; }
