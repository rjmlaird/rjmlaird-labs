export default function LengthContractionRod(){return null}
