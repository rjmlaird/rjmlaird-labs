# Physics notes

For β = v/c, the Lorentz factor is γ = 1 / √(1 − β²).

Time dilation: Δt = γ Δτ.

Length contraction: L = L₀ / γ, for a length measured parallel to the direction of motion.

The UI includes a relativistic-mass readout as an historical convention, m_rel = γm. Modern relativity normally treats invariant/rest mass as unchanged and instead describes total energy E = γmc² and momentum p = γmv.

The visualisations are illustrative rather than precision simulations. The train and light-clock scenes are designed to communicate frame-dependent measurements and the role of c as an invariant speed.


## Spacetime diagrams and simultaneity

A Minkowski diagram plots position `x` horizontally and time `ct` vertically. Light rays follow 45-degree lines when both axes use compatible units. A frame moving at velocity `v` has transformed coordinates given by the Lorentz transformation. Its time axis is the worldline `x = vt`, while its spatial axis represents events simultaneous in the moving frame.

This playground uses schematic diagrams rather than a metrically exact plotting system; the visual goal is to make the tilt of the moving frame intuitive.

For two events at the same platform-frame time, the Lorentz transformation gives `Δt′ = γ(Δt − vΔx/c²)`. With `Δt = 0` and non-zero spatial separation, `Δt′` is generally non-zero: simultaneity is frame-dependent.
