# Satellites (Vercel)

Astro static site + two Vercel Functions that front Celestrak, with caching at three levels.

```
browser ──► IndexedDB cache (2h fresh, 24h stale-while-revalidate)
   │
   └──► /api/gp, /api/satcat ──► Vercel edge cache (s-maxage 2h, SWR 24h, stale-if-error 7d)
                                   │
                                   └──► Celestrak (warm instances keep the parsed SATCAT and each GP group in memory; a 403/429 pauses that group for 2h and serves stale data)
```

| Route | Returns |
| --- | --- |
| `/api/gp?group=stations` | GP element sets for the group as CSV (OMM). CSV, not TLE, because TLEs cannot hold NORAD ids above 99999 |
| `/api/satcat?group=stations` | SATCAT rows for only that group's objects, trimmed to the columns the app uses |
| `/api/satcat?scope=payloads` | Payload-only table (type, owner, launch date) for Launch Stats |

## Deploy

1. Push this folder to a repo (or keep it in the monorepo and set **Root Directory** to `packages/satellites` in Vercel).
2. Import in Vercel. Framework preset: Astro (detected from `vercel.json`). No env vars needed.
3. Add the domain `satellites.labs.rjmlaird.co.uk` under Project → Domains.

## Local

```
npm install
npm run vercel:dev   # runs Astro + /api together (plain `astro dev` has no /api)
npm test             # API tests (mocked Celestrak)
```

## Notes

- Allowed groups live in `api/_lib/celestrak.js`; add more with the `EXTRA_GROUPS` env var (comma-separated).
- Verify edge caching after deploy: `curl -sI 'https://<domain>/api/gp?group=stations' | grep -i x-vercel-cache` — expect `MISS` once, then `HIT`.
- Cache lifetimes: `CACHE_CONTROL` in `api/_lib/celestrak.js` (server) and `TTL_MS` / `SWR_MS` in `src/scripts/lib/cache.ts` (browser).
- `public/data/satcat.csv` is only a fallback snapshot for `/api/satcat` when CelesTrak is unreachable. Refresh it occasionally.
- `/api/satcat?group=` reuses the cached GP download from `/api/gp`, so each group costs one CelesTrak request per cycle.
- Requires Node >= 22.12 (Astro 7).
- The Cloudflare worker and `wrangler.jsonc` are gone; static caching headers are in `vercel.json`.
