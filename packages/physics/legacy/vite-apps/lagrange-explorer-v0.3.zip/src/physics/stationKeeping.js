function clampMagnitude(v, max) {
  const m = Math.hypot(...v);
  if (m <= max || m === 0) return v;
  const scale = max / m;
  return v.map(x => x * scale);
}

/**
 * Simple proportional-derivative station keeping.
 *
 * This is a visual teaching model, not a flight-dynamics controller.
 * It applies an instantaneous delta-v when the spacecraft leaves a
 * configurable position threshold around the chosen L-point.
 */
export function stationKeepingImpulse(
  state,
  target,
  {
    threshold = 0.004,
    positionGain = 0.02,
    velocityGain = 0.35,
    maxDeltaV = 0.00008
  } = {}
) {
  const error = [
    target.x - state[0],
    target.y - state[1],
    target.z - state[2]
  ];

  const distance = Math.hypot(...error);
  if (distance <= threshold) {
    return { deltaV: [0, 0, 0], distance, corrected: false };
  }

  const raw = [
    error[0] * positionGain - state[3] * velocityGain,
    error[1] * positionGain - state[4] * velocityGain,
    error[2] * positionGain - state[5] * velocityGain
  ];

  return {
    deltaV: clampMagnitude(raw, maxDeltaV),
    distance,
    corrected: true
  };
}

export function applyDeltaV(state, deltaV) {
  return [
    state[0], state[1], state[2],
    state[3] + deltaV[0],
    state[4] + deltaV[1],
    state[5] + deltaV[2]
  ];
}

export function deltaVMagnitude(deltaV) {
  return Math.hypot(...deltaV);
}
