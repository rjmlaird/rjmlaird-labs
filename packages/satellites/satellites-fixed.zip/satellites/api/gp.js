// GET /api/gp?group=stations -> GP element sets (CSV / OMM) for one group.
//
// CSV rather than TLE: TLEs cannot represent NORAD catalog numbers above
// 99999, and those are now in use. The client turns each row into an SGP4
// record with satellite.js json2satrec().
import {
  CACHE_CONTROL,
  errorResponse,
  getCachedGroup,
  parseGpNoradIds,
  readGroup,
  UpstreamError,
} from './_lib/celestrak.js';

export async function GET(request) {
  const group = readGroup(request);
  if (group instanceof Response) return group;

  try {
    const result = await getCachedGroup(group, 'CSV');
    const recordCount = parseGpNoradIds(result.text).length;

    // CelesTrak answers "No GP data found" with HTTP 200.
    if (recordCount === 0) {
      return errorResponse(404, `CelesTrak returned no element sets for "${group}".`, { group });
    }

    return new Response(result.text, {
      status: 200,
      headers: {
        'content-type': 'text/csv; charset=utf-8',
        'cache-control': CACHE_CONTROL,
        'x-celestrak-group': group,
        'x-celestrak-record-count': String(recordCount),
        'x-data-age-seconds': String(result.ageSeconds ?? ''),
        'x-data-stale': result.stale ? 'true' : 'false',
      },
    });
  } catch (error) {
    if (error instanceof UpstreamError) {
      return errorResponse(error.status || 502, error.message, {
        group,
        retryAfterSeconds: error.retryAfterSeconds,
      });
    }
    console.error('GP route failed', { group, error });
    return errorResponse(500, 'Unexpected error.', { group });
  }
}
