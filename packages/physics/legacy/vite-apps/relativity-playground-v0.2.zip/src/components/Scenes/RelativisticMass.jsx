export default function RelativisticMass(){return null}
