import React, { useEffect, useMemo, useRef, useState } from 'react';
import './index.css';
import { SYSTEMS, lagrangePoints, derivatives, jacobiConstant } from './physics/threeBody.js';
import { rk4Step } from './utils/integrators.js';
import { haloSeed, lissajousSeed, ORBIT_TYPES } from './physics/orbitInitialConditions.js';
import { stationKeepingImpulse, applyDeltaV, deltaVMagnitude } from './physics/stationKeeping.js';

const missions = [
  { name: 'JWST', system: 'sunEarth', point: 'L2', note: 'Sun–Earth L2 halo orbit' },
  { name: 'SOHO', system: 'sunEarth', point: 'L1', note: 'Sun–Earth L1 halo/Lissajous region' },
  { name: 'LISA Pathfinder', system: 'sunEarth', point: 'L1', note: 'Sun–Earth L1 region' },
  { name: 'ARTEMIS', system: 'earthMoon', point: 'L1/L2', note: 'Earth–Moon libration orbits' }
];

function makeInitialState(sys, points, point, orbitType, amplitude) {
  const p = points[point];
  if (orbitType === 'lissajous') return lissajousSeed(p, sys.mu, amplitude);
  if (orbitType === 'halo') return haloSeed(p, sys.mu, amplitude, amplitude * 0.8);
  return [p.x + amplitude, p.y, p.z, 0, 0, 0];
}

function App() {
  const [system, setSystem] = useState('earthMoon');
  const [point, setPoint] = useState('L2');
  const [orbitType, setOrbitType] = useState('halo');
  const [amplitude, setAmplitude] = useState(0.002);
  const [playing, setPlaying] = useState(true);
  const [speed, setSpeed] = useState(1);
  const [stationKeeping, setStationKeeping] = useState(false);
  const [threshold, setThreshold] = useState(0.004);
  const [state, setState] = useState(null);
  const [trail, setTrail] = useState([]);
  const [dv, setDv] = useState(0);
  const [corrections, setCorrections] = useState(0);
  const sys = SYSTEMS[system];
  const points = useMemo(() => lagrangePoints(sys.mu), [sys.mu]);

  const reset = () => {
    const s = makeInitialState(sys, points, point, orbitType, amplitude);
    setState(s);
    setTrail([s]);
    setDv(0);
    setCorrections(0);
  };

  useEffect(reset, [system, point, orbitType, amplitude]);

  useEffect(() => {
    if (!playing || !state) return undefined;
    let raf;
    let last = performance.now();
    let accumulator = 0;
    let frameState = state;
    let pendingTrail = [];
    let pendingDv = 0;
    let pendingCorrections = 0;

    const tick = now => {
      const elapsed = Math.min((now - last) / 1000, 0.05);
      last = now;
      accumulator += elapsed * speed;
      let steps = 0;

      while (accumulator >= sys.dt && steps < 40) {
        frameState = rk4Step(frameState, sys.dt, x => derivatives(x, sys.mu));
        accumulator -= sys.dt;
        steps += 1;

        if (stationKeeping && steps % 5 === 0) {
          const correction = stationKeepingImpulse(frameState, points[point], {
            threshold,
            positionGain: 0.025,
            velocityGain: 0.45,
            maxDeltaV: 0.00008
          });
          if (correction.corrected) {
            frameState = applyDeltaV(frameState, correction.deltaV);
            pendingDv += deltaVMagnitude(correction.deltaV);
            pendingCorrections += 1;
          }
        }
      }

      if (steps) {
        pendingTrail.push(frameState);
        if (pendingTrail.length >= 3) {
          const additions = pendingTrail;
          pendingTrail = [];
          setState(frameState);
          setTrail(old => [...old, ...additions].slice(-2200));
          if (pendingDv) {
            const d = pendingDv;
            const c = pendingCorrections;
            pendingDv = 0;
            pendingCorrections = 0;
            setDv(v => v + d);
            setCorrections(v => v + c);
          }
        }
      }
      raf = requestAnimationFrame(tick);
    };

    raf = requestAnimationFrame(tick);
    return () => cancelAnimationFrame(raf);
  }, [playing, speed, sys, state, stationKeeping, threshold, point, points]);

  const target = points[point];
  const distance = state ? Math.hypot(state[0] - target.x, state[1] - target.y, state[2] - target.z) : 0;

  return (
    <main>
      <header>
        <div>
          <span className="eyebrow">ORBITAL DYNAMICS LAB</span>
          <h1>Lagrange Point Explorer</h1>
          <p>Seed a Lissajous or halo-like orbit near L1/L2, perturb it, and see why real missions need trajectory control and station-keeping.</p>
        </div>
        <div className="badge">CR3BP · RK4 · Δv</div>
      </header>

      <section className="layout">
        <div className="card canvas">
          <SimCanvas system={sys} points={points} state={state} trail={trail} target={target} />
        </div>
        <aside className="card controls">
          <label>System<select value={system} onChange={e => setSystem(e.target.value)}><option value="earthMoon">Earth–Moon</option><option value="sunEarth">Sun–Earth</option></select></label>
          <label>Target point<select value={point} onChange={e => setPoint(e.target.value)}>{Object.keys(points).map(k => <option key={k}>{k}</option>)}</select></label>
          <label>Orbit seed<select value={orbitType} onChange={e => setOrbitType(e.target.value)}>{ORBIT_TYPES.map(o => <option key={o.id} value={o.id}>{o.label}</option>)}</select></label>
          <label>Orbit amplitude <b>{amplitude.toFixed(4)} canonical</b><input type="range" min="0.0001" max="0.02" step="0.0001" value={amplitude} onChange={e => setAmplitude(+e.target.value)} /></label>
          <label>Simulation speed <b>{speed}×</b><input type="range" min="0.25" max="8" step="0.25" value={speed} onChange={e => setSpeed(+e.target.value)} /></label>
          <div className="toggle"><label><input type="checkbox" checked={stationKeeping} onChange={e => setStationKeeping(e.target.checked)} /> Enable station-keeping</label></div>
          <label>Correction threshold <b>{threshold.toFixed(4)}</b><input type="range" min="0.001" max="0.02" step="0.0005" value={threshold} onChange={e => setThreshold(+e.target.value)} /></label>
          <div className="buttons"><button onClick={() => setPlaying(v => !v)}>{playing ? 'Pause' : 'Play'}</button><button onClick={reset}>Reset</button></div>
          <div className="readout">
            <div><span>μ</span><strong>{sys.mu.toFixed(9)}</strong></div>
            <div><span>Jacobi C</span><strong>{state ? jacobiConstant(state, sys.mu).toFixed(6) : '—'}</strong></div>
            <div><span>Distance from L-point</span><strong>{distance.toExponential(2)}</strong></div>
            <div><span>Cumulative Δv</span><strong>{dv.toExponential(3)} canonical</strong></div>
            <div><span>Corrections</span><strong>{corrections}</strong></div>
          </div>
          <p className="note">The halo/Lissajous seeds are educational approximations, not JWST flight ephemerides. Station-keeping here is a simple proportional-derivative impulse model.</p>
        </aside>
      </section>

      <section className="bottom">
        <div className="card">
          <h2>Why JWST does not “sit” at L2</h2>
          <p>Sun–Earth L2 is an equilibrium in the idealised rotating model, but a mission does not simply park a spacecraft there. Real missions use bounded halo/Lissajous trajectories, with navigation and small corrective manoeuvres to manage unstable dynamics and perturbations that the ideal CR3BP omits.</p>
          <div className="mission-grid">{missions.filter(m => m.system === system).map(m => <div className="mission" key={m.name}><b>{m.name}</b><span>{m.point}</span><small>{m.note}</small></div>)}</div>
        </div>
        <div className="card equations">
          <h2>Model</h2>
          <p>Canonical rotating-frame CR3BP:</p>
          <code>ẍ − 2ẏ = ∂Ω/∂x<br />ÿ + 2ẋ = ∂Ω/∂y<br />z̈ = ∂Ω/∂z</code>
          <p><code>Ω = ½(x²+y²) + (1−μ)/r₁ + μ/r₂</code></p>
          <p className="muted">Orbit seeds come from the linearised dynamics around a collinear point. A true halo-family solution requires nonlinear correction/continuation.</p>
        </div>
      </section>
      <footer>Demo-first educational model · Canonical units · See <code>docs/physics-notes.md</code> and <code>docs/orbits-and-station-keeping.md</code>.</footer>
    </main>
  );
}

function SimCanvas({ system, points, state, trail, target }) {
  const ref = useRef();
  useEffect(() => {
    const c = ref.current;
    const ctx = c.getContext('2d');
    const dpr = devicePixelRatio || 1;
    const w = c.clientWidth;
    const h = c.clientHeight;
    c.width = w * dpr;
    c.height = h * dpr;
    ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
    ctx.clearRect(0, 0, w, h);
    ctx.fillStyle = '#091016';
    ctx.fillRect(0, 0, w, h);
    const scale = Math.min(w, h) * 0.82;
    const sx = x => w / 2 + x * scale;
    const sy = y => h / 2 - y * scale;

    ctx.strokeStyle = '#1d2b34';
    ctx.lineWidth = 1;
    for (let i = -5; i <= 5; i++) {
      ctx.beginPath(); ctx.moveTo(sx(i / 5), 0); ctx.lineTo(sx(i / 5), h); ctx.stroke();
      ctx.beginPath(); ctx.moveTo(0, sy(i / 5)); ctx.lineTo(w, sy(i / 5)); ctx.stroke();
    }
    ctx.strokeStyle = '#40515a';
    ctx.beginPath(); ctx.moveTo(0, sy(0)); ctx.lineTo(w, sy(0)); ctx.stroke();

    for (const [k, p] of Object.entries(points)) {
      ctx.fillStyle = ['L1', 'L2', 'L3'].includes(k) ? '#e7b75a' : '#79c7c0';
      ctx.beginPath(); ctx.arc(sx(p.x), sy(p.y), k === 'L4' || k === 'L5' ? 4 : 3, 0, Math.PI * 2); ctx.fill();
      ctx.fillStyle = '#9aa9b2'; ctx.font = '12px system-ui'; ctx.fillText(k, sx(p.x) + 7, sy(p.y) - 7);
    }
    ctx.fillStyle = '#b8d6e0';
    for (const b of system.bodies) { ctx.beginPath(); ctx.arc(sx(b.x), sy(b.y), b.radius, 0, Math.PI * 2); ctx.fill(); }

    if (target) {
      ctx.strokeStyle = '#e7b75a'; ctx.setLineDash([3, 4]);
      ctx.beginPath(); ctx.arc(sx(target.x), sy(target.y), 13, 0, Math.PI * 2); ctx.stroke(); ctx.setLineDash([]);
    }
    if (trail.length > 1) {
      ctx.strokeStyle = '#6dc5e8'; ctx.globalAlpha = 0.75; ctx.lineWidth = 1.5;
      ctx.beginPath(); trail.forEach((p, i) => i ? ctx.lineTo(sx(p[0]), sy(p[1])) : ctx.moveTo(sx(p[0]), sy(p[1]))); ctx.stroke(); ctx.globalAlpha = 1;
    }
    if (state) {
      ctx.fillStyle = '#fff'; ctx.beginPath(); ctx.arc(sx(state[0]), sy(state[1]), 5, 0, Math.PI * 2); ctx.fill();
    }
  }, [system, points, state, trail, target]);
  return <canvas ref={ref} />;
}

export default App;
