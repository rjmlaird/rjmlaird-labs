# Halo/Lissajous seeds and station-keeping

## Scope

The playground now offers three initial-condition modes near a collinear Lagrange point:

- **L-point equilibrium** — starts at the numerical equilibrium, with a small configurable offset.
- **Lissajous seed** — uses the centre-frequency mode of the linearised planar CR3BP around L1/L2.
- **Halo seed** — adds a small out-of-plane displacement to the planar centre mode, giving a useful 3-D halo-like visual seed.

These are **not mission ephemerides**. A flight-quality halo orbit normally comes from nonlinear differential correction, continuation, and a higher-fidelity dynamical model.

## Why the seed is useful

Near a collinear point, the linearised system contains both unstable/stable directions and oscillatory modes. A small combination of the oscillatory planar mode and vertical motion therefore gives an intuitive starting point for a bounded Lissajous/halo-like trajectory. Nonlinear terms eventually matter, which is exactly what the playground is intended to expose.

## Station-keeping model

When enabled, the simulation checks the spacecraft's 3-D distance from the target point. Once it exceeds a threshold, it applies an instantaneous proportional-derivative correction:

`Δv = clamp(Kp * position_error − Kd * velocity, max_Δv)`

This is intentionally simple. It demonstrates the concept of repeated small corrections and reports cumulative canonical Δv and correction count. It is **not** a flight-dynamics controller and should not be interpreted as a JWST propellant budget.

## Canonical Δv

CR3BP velocity units are `a n`, where `a` is the primary separation and `n` is the system mean motion. To convert a canonical velocity increment to SI units:

`Δv_SI = Δv_canonical × a × n`

The UI keeps canonical units explicit to avoid implying false precision.

## JWST context

JWST operates in a halo orbit around the Sun–Earth L2 region rather than occupying the exact mathematical L2 equilibrium. The mission must perform trajectory correction and station-keeping manoeuvres. This lab models that idea qualitatively using the CR3BP and a simple controller; it does not reproduce JWST's operational trajectory.
