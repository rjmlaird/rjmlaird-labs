export default function MovingTrain(){return null}
