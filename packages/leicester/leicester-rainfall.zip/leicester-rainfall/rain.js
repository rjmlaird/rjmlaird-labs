// One call from the browser -> list rainfall gauges near a point, fetch each gauge's last 7 days of
// 15-minute readings in parallel, and return compact hourly totals. Edge-cached 10 min.
// h[k] = mm in the k-th hour back from "generated" (h[0] = last hour). null = no reading received.
const BASE = 'https://environment.data.gov.uk/flood-monitoring';
const J = async (p) => {
  const r = await fetch(BASE + p, { headers: { Accept: 'application/json' }, signal: AbortSignal.timeout(20000) });
  if (!r.ok) throw new Error(`${r.status} ${p}`);
  return r.json();
};

module.exports = async (req, res) => {
  const lat = +req.query.lat, lon = +req.query.lon, km = Math.round(+req.query.km);
  if (!(lat > 49 && lat < 56 && lon > -7 && lon < 2 && km >= 1 && km <= 60)) return res.status(400).json({ error: 'bad params' });
  const now = Date.now(), since = new Date(now - 7 * 864e5).toISOString();
  try {
    const stations = [].concat((await J(`/id/stations?parameter=rainfall&lat=${lat}&long=${lon}&dist=${km}&_limit=200`)).items || []);
    const gauges = (await Promise.all(stations.map(async (s) => {
      const m = [].concat(s.measures || []).find((x) => x.parameter === 'rainfall');
      if (!m || !isFinite(s.lat) || !isFinite(s.long)) return null;
      let items = [];
      try { items = (await J(`/id/measures/${String(m['@id']).split('/').pop()}/readings?since=${since}&_sorted&_limit=800`)).items || []; } catch (e) { /* keep gauge, no data */ }
      const h = new Array(168).fill(null);
      let lastT = null, latest = null;
      for (const r of items) {
        const t = Date.parse(r.dateTime), v = Array.isArray(r.value) ? r.value[0] : r.value;
        if (!isFinite(t) || typeof v !== 'number' || !isFinite(v)) continue;
        const k = Math.floor((now - t) / 36e5);
        if (k < 0 || k > 167) continue;
        h[k] = Math.round(((h[k] || 0) + v) * 100) / 100;
        if (lastT == null || t > lastT) { lastT = t; latest = v; }
      }
      return { ref: s.stationReference || s.notation, grid: s.gridReference, lat: s.lat, lon: s.long, h, lastT, latest };
    }))).filter(Boolean);
    res.setHeader('Cache-Control', 'public, s-maxage=600, stale-while-revalidate=1800');
    res.status(200).json({ generated: now, gauges });
  } catch (e) {
    res.status(502).json({ error: String(e) });
  }
};
