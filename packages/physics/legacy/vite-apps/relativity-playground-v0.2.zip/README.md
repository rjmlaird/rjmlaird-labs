# Relativity Playground

A visual, intuition-first special-relativity sandbox built with React + Vite and Canvas.

## Features

- Speed control from 0 to 0.999c
- Lorentz factor γ readout
- Animated light clock, moving train, length-contraction and energy/mass scenes
- Time dilation and length-contraction readouts
- Relativistic-mass convention clearly labelled, with modern energy interpretation
- Responsive dark UI

## Run

```bash
npm install
npm run dev
```

## Physics

The core model uses special relativity in flat spacetime. See `src/physics/relativity.js` and `docs/physics-notes.md`.
