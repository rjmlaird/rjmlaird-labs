export const C = 299792458;
