// Shared helpers for talking to the Celestrak proxy API (/api/*) and parsing
// its data formats. Used by satellite-ground-track.ts, satellite-passes.ts and
// launch-stats.ts so the features stay consistent.
//
// Data flow: browser -> IndexedDB cache -> /api/* (Vercel, edge-cached 2h)
// -> Celestrak. The API trims the SATCAT down to the rows/columns the app
// needs, so payloads are small and Celestrak is not hit per visitor.

import { cachedFetchText } from './cache';

/** TLE text for a Celestrak GP group. */
export function gpUrl(group: string) {
  return `/api/gp?group=${encodeURIComponent(group)}`;
}

/** SATCAT rows for only the objects in a GP group (same CSV shape as Celestrak's). */
export function satcatUrl(group: string) {
  return `/api/satcat?group=${encodeURIComponent(group)}`;
}

/** Payload-only SATCAT table (type, owner, launch date) for Launch Stats. */
export const SATCAT_PAYLOADS_URL = '/api/satcat?scope=payloads';

/** Fetch text from the API through the browser cache (see ./cache.ts). */
export function fetchText(url: string): Promise<string> {
  return cachedFetchText(url);
}

export type TLEEntry = { name: string; noradId: number; l1: string; l2: string };

export function parseTLE(text: string): TLEEntry[] {
  const lines = text.split(/\r?\n/).filter((l) => l.trim().length > 0);
  const out: TLEEntry[] = [];
  for (let i = 0; i + 2 < lines.length; i += 3) {
    const name = lines[i].trim();
    const l1 = lines[i + 1];
    const l2 = lines[i + 2];
    if (!l1.startsWith('1 ') || !l2.startsWith('2 ')) continue;
    const noradId = parseInt(l1.substring(2, 7).trim(), 10);
    out.push({ name, noradId, l1, l2 });
  }
  return out;
}

export function splitCSVLine(line: string): string[] {
  const result: string[] = [];
  let cur = '';
  let inQ = false;
  for (let i = 0; i < line.length; i++) {
    const c = line[i];
    if (c === '"') {
      if (inQ && line[i + 1] === '"') {
        cur += '"';
        i++;
      } else inQ = !inQ;
    } else if (c === ',' && !inQ) {
      result.push(cur);
      cur = '';
    } else {
      cur += c;
    }
  }
  result.push(cur);
  return result;
}

export type SatcatKeys = {
  norad: string | null;
  status: string | null;
  type: string | null;
  owner: string | null;
  launch: string | null;
  site: string | null;
  decay: string | null;
  period: string | null;
  incl: string | null;
  apogee: string | null;
  perigee: string | null;
  rcs: string | null;
  objid: string | null;
  orbit: string | null;
  name: string | null;
};

export type SatCatParse = {
  rows: Record<string, string>[];
  keys: SatcatKeys;
};

/**
 * Parse SATCAT CSV text. Column names are resolved by pattern rather than
 * hard-coded position, since Celestrak has changed column order before.
 */
export function parseSatcat(text: string): SatCatParse {
  const lines = text.split(/\r?\n/).filter((l) => l.length > 0);
  if (!lines.length) return { rows: [], keys: {} as SatcatKeys };
  const headers = splitCSVLine(lines[0]).map((h) => h.trim());
  const rows: Record<string, string>[] = [];

  for (let i = 1; i < lines.length; i++) {
    const vals = splitCSVLine(lines[i]);
    const obj: Record<string, string> = {};
    headers.forEach((h, idx) => (obj[h] = vals[idx] !== undefined ? vals[idx].trim() : ''));
    rows.push(obj);
  }

  const findKey = (re: RegExp) => headers.find((h) => re.test(h)) || null;

  return {
    rows,
    keys: {
      norad: findKey(/NORAD.*CAT.*ID/i),
      status: findKey(/OPS.*STATUS/i),
      type: findKey(/OBJECT_TYPE/i),
      owner: findKey(/OWNER/i),
      launch: findKey(/LAUNCH_DATE/i),
      site: findKey(/LAUNCH_SITE/i),
      decay: findKey(/DECAY_DATE/i),
      period: findKey(/^PERIOD$/i),
      incl: findKey(/INCLINATION/i),
      apogee: findKey(/APOGEE/i),
      perigee: findKey(/PERIGEE/i),
      rcs: findKey(/RCS/i),
      objid: findKey(/OBJECT_ID/i),
      orbit: findKey(/ORBIT_TYPE/i),
      name: findKey(/^OBJECT_NAME$/i),
    },
  };
}

export function escapeHtml(s: string): string {
  const d = document.createElement('div');
  d.textContent = s;
  return d.innerHTML;
}

export function get(cat: Record<string, string>, catKeys: SatcatKeys, key: keyof SatcatKeys): string {
  const k = catKeys[key];
  return k ? cat[k] || '—' : '—';
}
