import test from 'node:test';
import assert from 'node:assert/strict';

const SATCAT = [
  'OBJECT_NAME,OBJECT_ID,NORAD_CAT_ID,OBJECT_TYPE,OPS_STATUS_CODE,OWNER,LAUNCH_DATE,LAUNCH_SITE,DECAY_DATE,PERIOD,INCLINATION,APOGEE,PERIGEE,RCS,DATA_STATUS_CODE,ORBIT_CENTER,ORBIT_TYPE',
  'ISS (ZARYA),1998-067A,25544,PAY,+,ISS,1998-11-20,TTMTR,,92.9,51.6,420,418,399.05,,EA,ORB',
  '"FOO, BAR",2020-001A,99001,PAY,+,US,2020-01-02,AFETR,,95,53,550,540,,,EA,ORB',
  'SL-8 R/B,1970-001B,99002,R/B,,CIS,1970-02-02,PKMTR,,100,82,900,800,,,EA,ORB',
  'DEB,1999-025A,99003,DEB,,PRC,1999-05-05,TAIYU,,100,98,900,800,,,EA,ORB',
].join('\n');

const GP_HEADER =
  'OBJECT_NAME,OBJECT_ID,EPOCH,MEAN_MOTION,ECCENTRICITY,INCLINATION,RA_OF_ASC_NODE,ARG_OF_PERICENTER,MEAN_ANOMALY,EPHEMERIS_TYPE,CLASSIFICATION_TYPE,NORAD_CAT_ID,ELEMENT_SET_NO,REV_AT_EPOCH,BSTAR,MEAN_MOTION_DOT,MEAN_MOTION_DDOT';
const gpRow = (name, id) =>
  `${name},1998-067A,2026-10-06T00:00:00.000000,15.5,0.0001,51.6,0,0,0,0,U,${id},999,10,0.0001,0.0001,0`;
const GP_STATIONS = [GP_HEADER, gpRow('ISS (ZARYA)', 25544), gpRow('FOO', 99001), gpRow('GHOST', 12345), gpRow('SIX DIGIT', 100881)].join('\n');

let calls = [];
let stationsStatus = 200;
globalThis.fetch = async (url) => {
  calls.push(String(url));
  const u = String(url);
  if (u.includes('satcat.csv')) return new Response(SATCAT);
  if (u.includes('GROUP=stations')) return new Response(GP_STATIONS, { status: stationsStatus });
  if (u.includes('GROUP=weather')) return new Response('No GP data found');
  return new Response('nope', { status: 500 });
};

const gp = await import('../api/gp.js');
const lib = await import('../api/_lib/celestrak.js');
const satcat = await import('../api/satcat.js');
const req = (path) => new Request('https://x.test' + path);

test('gp: returns GP CSV with long-lived cache headers', async () => {
  lib.clearAllCache();
  const r = await gp.GET(req('/api/gp?group=stations'));
  assert.equal(r.status, 200);
  assert.match(r.headers.get('cache-control'), /s-maxage=7200/);
  assert.match(r.headers.get('cache-control'), /stale-while-revalidate/);
  assert.equal(r.headers.get('x-celestrak-record-count'), '4');
  assert.match(await r.text(), /^OBJECT_NAME,.*NORAD_CAT_ID/);
});

test('gp: second request is served from memory, not CelesTrak', async () => {
  calls = [];
  await gp.GET(req('/api/gp?group=stations'));
  assert.equal(calls.length, 0);
});

test('gp: rejects unknown and missing groups, never calls upstream', async () => {
  calls = [];
  assert.equal((await gp.GET(req('/api/gp?group=../../etc'))).status, 400);
  assert.equal((await gp.GET(req('/api/gp'))).status, 400);
  assert.equal(calls.length, 0);
});

test('gp: empty upstream result is a 404 and not cached', async () => {
  const r = await gp.GET(req('/api/gp?group=weather'));
  assert.equal(r.status, 404);
  assert.equal(r.headers.get('cache-control'), 'no-store');
});

test('satcat: slices to group members, trims columns, keeps quoted cells', async () => {
  const r = await satcat.GET(req('/api/satcat?group=stations'));
  assert.equal(r.status, 200);
  const lines = (await r.text()).split('\n');
  assert.equal(lines.length, 3); // header + ISS + FOO (GHOST and the 6-digit id are not in the test SATCAT)
  assert.ok(!lines[0].includes('DECAY_DATE'));
  assert.ok(!lines[0].includes('OBJECT_NAME'));
  assert.match(lines[0], /NORAD_CAT_ID/);
  assert.match(lines[1], /^1998-067A,25544,PAY/);
});

test('satcat: payloads scope has only PAY rows and 3 columns', async () => {
  const r = await satcat.GET(req('/api/satcat?scope=payloads'));
  const lines = (await r.text()).split('\n');
  assert.equal(lines[0], 'OBJECT_TYPE,OWNER,LAUNCH_DATE');
  assert.equal(lines.length, 3);
  assert.ok(lines.slice(1).every((l) => l.startsWith('PAY,')));
});

test('satcat: warm instance reuses the SATCAT download', async () => {
  calls = [];
  await satcat.GET(req('/api/satcat?group=stations'));
  await satcat.GET(req('/api/satcat?scope=payloads'));
  assert.equal(calls.filter((c) => c.includes('satcat.csv')).length, 0);
});

test('satcat: group request reuses the cached GP download', async () => {
  calls = [];
  await satcat.GET(req('/api/satcat?group=stations'));
  assert.equal(calls.filter((c) => c.includes('gp.php')).length, 0);
});

test('gp: a 403 starts a cooldown and is not retried', async () => {
  lib.clearAllCache();
  stationsStatus = 403;
  calls = [];
  const first = await gp.GET(req('/api/gp?group=stations'));
  assert.equal(first.status, 503);
  assert.ok(Number(first.headers.get('retry-after')) > 0);
  assert.equal(first.headers.get('cache-control'), 'no-store');
  await gp.GET(req('/api/gp?group=stations'));
  assert.equal(calls.filter((c) => c.includes('gp.php')).length, 1);
  stationsStatus = 200;
  lib.clearAllCache();
});

test('parseGpNoradIds: reads CSV (including 6-digit ids) and legacy TLE text', () => {
  assert.deepEqual(lib.parseGpNoradIds(GP_STATIONS), [25544, 99001, 12345, 100881]);
  const tle = 'ISS\n1 25544U 98067A   26280.00000000  .00000000  00000-0  00000-0 0  9990\n2 25544  51.6000   0.0000 0001000   0.0000   0.0000 15.50000000    10\n';
  assert.deepEqual(lib.parseGpNoradIds(tle), [25544]);
});
