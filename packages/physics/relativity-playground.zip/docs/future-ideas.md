# Future ideas

- Relativity of simultaneity with train/platform flash events
- Twin paradox timeline
- Relativistic Doppler shift
- E = mc² mass-energy visualiser
- Minkowski spacetime diagram with draggable events
- Velocity addition explorer
- Rapidity as an alternative parameter
- Exportable classroom thought experiments
