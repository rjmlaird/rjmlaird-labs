# Future ideas

## Added in v0.2

- Minkowski-style spacetime diagram with platform-frame and moving-frame axes.
- Relativity of simultaneity scene showing how a horizontal simultaneity slice becomes tilted in a moving frame.

## Next candidates

- Twin paradox: compare proper time along two worldlines.
- Relativistic Doppler shift: moving source and observer.
- E = mc² visualiser.
- Interactive Lorentz transformation: drag an event and inspect `(t, x)` and `(t′, x′)`.
- Worldline trails and event markers.
- Rapidity as an alternative coordinate to velocity.
