export default function LightClock(){return null}
