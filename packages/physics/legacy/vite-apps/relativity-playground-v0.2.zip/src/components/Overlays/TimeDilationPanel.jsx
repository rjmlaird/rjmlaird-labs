export default function TimeDilationPanel(){return null}
