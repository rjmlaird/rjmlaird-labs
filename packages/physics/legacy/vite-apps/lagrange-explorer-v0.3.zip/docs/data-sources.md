# Data and mission context

System mass parameters are representative canonical values for the Earth–Moon and Sun–Earth CR3BP. Mission cards are contextual labels, not precise ephemeris data. JWST is represented as a Sun–Earth L2-region halo-orbit example; it is not assumed to sit at the exact mathematical L2 equilibrium.
