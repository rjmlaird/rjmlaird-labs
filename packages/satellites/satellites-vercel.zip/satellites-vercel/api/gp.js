// GET /api/gp?group=stations  ->  TLE text for a Celestrak GP group.
// Edge-cached (see CACHE_CONTROL) so Celestrak is hit at most ~once per 2h
// per group, instead of once per visitor.
import {
  CACHE_CONTROL,
  errorResponse,
  fetchUpstream,
  gpUpstream,
  parseTleNoradIds,
  readGroup,
  UpstreamError,
} from './_lib/celestrak.js';

export async function GET(request) {
  const group = readGroup(request);
  if (group instanceof Response) return group;

  try {
    const text = await fetchUpstream(gpUpstream(group));
    if (parseTleNoradIds(text).length === 0) {
      return errorResponse(404, `Celestrak returned no element sets for "${group}"`);
    }
    return new Response(text, {
      headers: { 'content-type': 'text/plain; charset=utf-8', 'cache-control': CACHE_CONTROL },
    });
  } catch (e) {
    if (e instanceof UpstreamError) return errorResponse(502, e.message);
    throw e;
  }
}
