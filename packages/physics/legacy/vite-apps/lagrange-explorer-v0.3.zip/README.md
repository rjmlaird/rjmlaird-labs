# Lagrange Point Explorer

A minimal interactive lab for exploring stability around Lagrange points in the Earth–Moon and Sun–Earth circular restricted three-body problem.

## Features

- L1–L5 calculated from the system mass ratio
- Small spacecraft perturbations
- RK4 trajectory integration
- Rotating-frame visualisation
- Jacobi constant diagnostic
- Earth–Moon and Sun–Earth presets
- Contextual mission markers including JWST and SOHO

## Run

```bash
npm install
npm run dev
```

This is an educational canonical-unit model, not a mission-design tool.


## Orbit and station-keeping modes

The current lab includes approximate Lissajous and halo-like initial-condition seeds plus an educational station-keeping controller. These are canonical-unit demonstrations rather than mission ephemerides. See `docs/orbits-and-station-keeping.md`.
