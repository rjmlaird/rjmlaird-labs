export const add=(a,b)=>a.map((v,i)=>v+b[i]);export const sub=(a,b)=>a.map((v,i)=>v-b[i]);export const scale=(a,k)=>a.map(v=>v*k);export const norm=a=>Math.hypot(...a);
